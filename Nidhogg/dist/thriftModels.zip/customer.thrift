namespace java com.frank0631.nidhog.customer

struct Customer {
    10:required string      firstName
    20:required string      lastName
}