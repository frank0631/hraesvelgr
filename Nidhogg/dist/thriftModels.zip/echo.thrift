namespace java com.frank0631.nidhog.echo

service TEchoService {
 string echo(1:string input);
}
